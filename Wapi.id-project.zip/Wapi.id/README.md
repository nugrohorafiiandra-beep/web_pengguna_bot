# Wapi.id Dashboard

Dashboard pengelola pengguna bot WhatsApp dengan penyimpanan SQLite lokal.

## Jalankan
1. Instal Node.js 18+.
2. Buka terminal di folder `Wapi.id`.
3. Jalankan `npm install`.
4. Jalankan `npm start`.
5. Buka `http://localhost:3000`.

Database akan dibuat otomatis pada `data/wapi.sqlite` saat server pertama kali dijalankan. Jangan hapus folder `data` jika ingin mempertahankan data.

## Isi
- `server.js` — server Express dan API CRUD
- `database.js` — skema serta inisialisasi SQLite
- `public/index.html` — dashboard responsive
- `data/` — database runtime (dibuat otomatis)

## Fitur
- Tambah, edit, dan hapus pengguna bot
- Status akun, paket, nomor WA, nama bot, dan masa aktif
- Perpanjang paket dan transaksi pemasukan otomatis
- CRUD transaksi pemasukan/pengeluaran (tambah/hapus)
- Toggle fitur bot
- Log aktivitas
- Data persisten di SQLite, bukan LocalStorage

Catatan: dashboard ini adalah panel pengelola dan belum menghubungkan sesi WhatsApp bot/QR pairing langsung. Tombol WhatsApp membuka chat wa.me dengan pesan yang sudah diisi.
