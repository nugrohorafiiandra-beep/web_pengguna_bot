const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');
const folder = path.join(__dirname, 'data');
fs.mkdirSync(folder, { recursive: true });
const db = new Database(path.join(folder, 'wapi.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  bot_name TEXT NOT NULL DEFAULT 'Wapi Bot',
  plan TEXT NOT NULL DEFAULT 'Basic',
  price INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'active',
  expires_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS features (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL DEFAULT '',
  enabled INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  title TEXT NOT NULL,
  amount INTEGER NOT NULL DEFAULT 0,
  type TEXT NOT NULL DEFAULT 'income',
  date TEXT NOT NULL DEFAULT (date('now','localtime')),
  status TEXT NOT NULL DEFAULT 'paid',
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS activities (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  description TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
`);
const count = db.prepare('SELECT COUNT(*) AS n FROM features').get().n;
if (!count) {
  const insert = db.prepare('INSERT INTO features(name,description,enabled) VALUES(?,?,?)');
  const list = [
    ['Auto-responder','Balas pesan otomatis berdasarkan kata kunci',1],
    ['Downloader','Unduh media dari layanan yang didukung',1],
    ['Game & hiburan','Mini game dan quiz ringan',1],
    ['Moderasi grup','Tools admin dan pengelolaan grup',1],
    ['Sticker maker','Konversi gambar menjadi stiker',1],
    ['AI assistant','Asisten tanya jawab',1],
    ['Info & tools','Kalkulator, informasi, dan utilitas',1],
    ['Menu interaktif','Menu command dan navigasi bot',1],
    ['Broadcast','Pengiriman pesan terjadwal/daftar opt-in',0],
    ['Reminder','Pengingat sesuai jadwal',0],
    ['Premium commands','Command untuk paket premium',0],
    ['Custom command','Command yang dapat diatur sendiri',0]
  ];
  const tx = db.transaction(list => list.forEach(x => insert.run(...x)));
  tx(list);
}
module.exports = db;
